By using this software, you agree to the terms of the MIT License included with this software in the LICENSE.txt file.

This software is meant to decompress the GOG offline installer for Firmament that you originally compressed for storage on a single dual layer DVD.

INSTRUCTIONS:

1. Run the "decompress.bat" batch script and enter the path to the directory where you would like the installation directory to be placed. Make sure it's somewhere with appropriate write permissions. It could potentially take HOURS depending on how powerful your PC is. It should take significantly less time than the original compression script.

2. Once the script is finished, you will have your original GOG offline installer and can run it to install Firmament and any dependencies.