By using this software, you agree to the terms of the MIT License included with this software in the LICENSE.txt file.

This software is meant to compress the GOG offline installer for Firmament to a small enough size to fit on a single dual layer DVD. When reading from the DVD in the future, it will then decompress the produced archive and recreate the original installer.

INSTRUCTIONS:

1. Run the "compress.bat" batch script and enter the path to the directory containing your installlation files. It could potentially take SEVERAL HOURS depending on how powerful your PC is.

2. Once the script is finished, everything you need to burn to DVD will be located in the "burn" folder.